package org.steamcheck.project.domain.usecase

import org.steamcheck.project.domain.model.GameDetail

class GetGameDetailsUseCase {
    fun execute(gameId: String): GameDetail {
        // Implémentation à ajouter
        return GameDetail("", "", "", "", "", "")
    }
}
