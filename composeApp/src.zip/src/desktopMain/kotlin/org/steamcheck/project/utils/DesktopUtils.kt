package org.steamcheck.project.utils

fun printMessage(message: String) {
    println(message)
}
