package org.steamcheck.project.ui.screens.gameslist

import androidx.compose.runtime.Composable

@Composable
fun GamesListScreen() {
    // Implémentation de l'écran de liste des jeux
}
