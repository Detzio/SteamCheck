package org.steamcheck.project.ui.screens.gamedetail

import androidx.compose.runtime.Composable

@Composable
fun GameDetailScreen() {
    // Implémentation de l'écran de détails d'un jeu
}
