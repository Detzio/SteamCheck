package org.steamcheck.project.data.remote.dto

data class UserDto(
    val id: String,
    val username: String,
    val avatarUrl: String
)
