package org.steamcheck.project.di

//import org.koin.core.module.Module
//
//val presentationModule: Module = org.koin.dsl.module {
    // Définir les dépendances de présentation ici
//}
