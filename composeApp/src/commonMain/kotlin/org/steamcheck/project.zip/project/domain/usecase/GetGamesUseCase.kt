package org.steamcheck.project.domain.usecase

import org.steamcheck.project.domain.model.Game

class GetGamesUseCase {
    fun execute(): List<Game> {
        // Implémentation à ajouter
        return emptyList()
    }
}
