package org.steamcheck.project.di

//import org.koin.core.module.Module
//
//val koinModule: Module = org.koin.dsl.module {
    // Définir les dépendances ici
//}
