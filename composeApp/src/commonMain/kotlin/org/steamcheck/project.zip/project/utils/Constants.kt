package org.steamcheck.project.utils

object Constants {
    const val BASE_URL = "https://api.steampowered.com"
    const val STEAM_API_KEY = "C1E650F345BD87FE5B419F664C8B9387"
}
