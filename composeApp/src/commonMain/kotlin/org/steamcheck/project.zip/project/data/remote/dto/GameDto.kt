package org.steamcheck.project.data.remote.dto

data class GameDto(
    val id: String,
    val name: String,
    val imageUrl: String
)
