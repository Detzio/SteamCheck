package org.steamcheck.project.di

//import org.koin.core.module.Module
//
//val domainModule: Module = org.koin.dsl.module {
    // Définir les dépendances du domaine ici
//}
