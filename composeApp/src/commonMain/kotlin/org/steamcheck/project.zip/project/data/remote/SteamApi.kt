package org.steamcheck.project.data.remote


import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.steamcheck.project.data.remote.dto.UserDto
import org.steamcheck.project.data.remote.dto.UserGameDto
import org.steamcheck.project.utils.Constants

interface SteamApi {
    suspend fun getUser(steamId: String): UserDto
}

class SteamApiImpl(private val client: HttpClient = ApiClient.client) : SteamApi {
    override suspend fun getUser(steamId: String): UserDto {
        val response = client.get("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/") {
            parameter("key", Constants.STEAM_API_KEY)
            parameter("steamids", steamId)
        }.body<JsonObject>()

        val userData = response["response"]?.jsonObject?.get("players")?.jsonArray?.firstOrNull()?.jsonObject

        return userData?.let {
            val isPrivate = it["communityvisibilitystate"]?.jsonPrimitive?.int != 3
            val games = if (!isPrivate) {
                // Récupérer les jeux si le compte est public
                fetchOwnedGames(steamId)
            } else {
                emptyList()
            }

            UserDto(
                id = it["steamid"]?.jsonPrimitive?.content ?: "",
                username = it["personaname"]?.jsonPrimitive?.content ?: "",
                avatarUrl = it["avatarfull"]?.jsonPrimitive?.content ?: "",
                steamID = it["steamid"]?.jsonPrimitive?.content ?: "",
                isPrivate = isPrivate,
                games = games
            )
        } ?: UserDto("", "", "", "", false, emptyList())
    }

    private suspend fun fetchOwnedGames(steamId: String): List<UserGameDto> {
        val response = client.get("https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/") {
            parameter("key", Constants.STEAM_API_KEY)
            parameter("steamid", steamId)
            parameter("include_appinfo", true)
            parameter("include_played_free_games", true)
            parameter("format", "json")
        }.body<JsonObject>()

        val gamesArray = response["response"]?.jsonObject?.get("games")?.jsonArray

        return gamesArray?.map { game ->
            val gameObj = game.jsonObject
            val appId = gameObj["appid"]?.jsonPrimitive?.content ?: ""
            val imageHash = gameObj["img_icon_url"]?.jsonPrimitive?.content ?: ""
            val imageUrl = if (imageHash.isNotEmpty()) {
                "http://media.steampowered.com/steamcommunity/public/images/apps/$appId/$imageHash.jpg"
            } else {
                ""
            }

            println("Game: $appId, Image URL: $imageUrl")

            UserGameDto(
                id = appId,
                name = gameObj["name"]?.jsonPrimitive?.content ?: "",
                imageUrl = imageUrl,
                totalSuccess = 0,
                ownedSuccess = 0
            )
        } ?: emptyList()
    }
}