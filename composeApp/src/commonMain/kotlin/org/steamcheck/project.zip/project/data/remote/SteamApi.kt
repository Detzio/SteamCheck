package org.steamcheck.project.data.remote

import kotlinx.serialization.json.JsonObject
import org.steamcheck.project.data.remote.dto.GameDetailDto
import org.steamcheck.project.data.remote.dto.GameDto
import org.steamcheck.project.data.remote.dto.UserDto
import org.steamcheck.project.data.remote.dto.UserStatsDto
import org.steamcheck.project.utils.Constants

interface SteamApi {
    suspend fun getGames(): List<GameDto>
    suspend fun getGameDetails(gameId: String): GameDetailDto
    suspend fun getUserBySteamId(steamId: String): UserDto {
        val response = client.get("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/") {
            parameter("key", Constants.STEAM_API_KEY)
            parameter("steamids", steamId)
        }

        val players = response.body<JsonObject>()["response"]?.jsonObject?.get("players")?.jsonArray
        val player = players?.firstOrNull()?.jsonObject ?: throw Exception("Utilisateur non trouvé")

        return UserDto(
            id = player["steamid"]?.jsonPrimitive?.content ?: "",
            username = player["personaname"]?.jsonPrimitive?.content ?: "",
            avatarUrl = player["avatarfull"]?.jsonPrimitive?.content ?: ""
        )
    }

}
