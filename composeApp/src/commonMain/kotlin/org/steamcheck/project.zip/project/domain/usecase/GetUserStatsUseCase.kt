package org.steamcheck.project.domain.usecase

//import org.steamcheck.project.domain.model.UserStats
//
//class GetUserStatsUseCase {
//    fun execute(userId: String): UserStats {
//        // Implémentation à ajouter
//        return UserStats("", 0, "", this.totalGames)
//    }
//}
